
const REGEX_EMAIL = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;



function exibirErro(campoId, mensagem) {
    const erroSpan = document.getElementById(`erro-${campoId}`);
    const inputElement = document.getElementById(campoId);
    if (erroSpan) {
        erroSpan.textContent = mensagem;
        inputElement.classList.add('invalido');
    }
}

function limparErro(campoId) {
    const erroSpan = document.getElementById(`erro-${campoId}`);
    const inputElement = document.getElementById(campoId);
    if (erroSpan) {
        erroSpan.textContent = '';
        inputElement.classList.remove('invalido');
    }
}



function validarNomeSobrenome(valor, campo, campoId) {
    limparErro(campoId);
    if (valor.trim() === '') {
        exibirErro(campoId, `${campo} não pode ser vazio.`);
        return false;
    }
    if (valor.length < 3 || valor.length > 50) {
        exibirErro(campoId, `${campo} deve ter entre 3 e 50 caracteres.`);
        return false;
    }
    return true;
}

function validarEmail(email) {
    limparErro('email');
    if (email.trim() === '') {
        exibirErro('email', 'E-mail não pode ser vazio.');
        return false;
    }
    if (!REGEX_EMAIL.test(email)) {
        exibirErro('email', 'Formato de e-mail inválido.');
        return false;
    }
    return true;
}

function validarIdade(idadeStr) {
    limparErro('idade');
    
    if (idadeStr.trim() === '') {
        exibirErro('idade', 'Idade não pode ser vazia.');
        return false;
    }
    
    const idade = parseInt(idadeStr, 10);

    if (isNaN(idade) || !Number.isInteger(idade) || idade <= 0 || idade >= 120) {
        exibirErro('idade', 'Idade deve ser um número inteiro positivo menor que 120.');
        return false;
    }
    return true;
}


/*
 * Função para baixar o objeto como arquivo JSON (usada no confirmation.html)
 */
function baixarJSON(dataObj, filename) {
    const jsonString = JSON.stringify(dataObj, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename; 
    
    document.body.appendChild(a);
    a.click();
    
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}


/*
 * Função principal de Submissão e Fluxo (para form.html)
 */
function validarEEnviar(event) {
    event.preventDefault(); 
    
    // 1. Recupera os valores
    const nome = document.getElementById('nome').value;
    const sobrenome = document.getElementById('sobrenome').value;
    const email = document.getElementById('email').value;
    const idade = document.getElementById('idade').value;

    // 2. Executa as validações
    const nomeValido = validarNomeSobrenome(nome, 'Nome', 'nome');
    const sobrenomeValido = validarNomeSobrenome(sobrenome, 'Sobrenome', 'sobrenome');
    const emailValido = validarEmail(email);
    const idadeValida = validarIdade(idade);

    const formularioValido = nomeValido && sobrenomeValido && emailValido && idadeValida;

    if (formularioValido) {
        
        // 3. Cria o objeto de dados final
        const dados = {
            nome: nome.trim(),
            sobrenome: sobrenome.trim(),
            email: email.trim(),
            idade: parseInt(idade, 10) 
        };

        // 4. Salva no sessionStorage para exibição e download posterior
        sessionStorage.setItem('dadosFormulario', JSON.stringify(dados));
        
        // 5. Redireciona para confirmation.html
        window.location.href = 'confirmation.html';

    } else {
        console.log("Submissão bloqueada: Formulário inválido.");
    }
}


/*
 * Bloco de Inicialização (Gerencia o fluxo em ambas as páginas)
 */
document.addEventListener('DOMContentLoaded', () => {
    
    // --- Lógica para form.html (Validação e Pré-preenchimento) ---
    if (window.location.pathname.endsWith('form.html')) {
        
        // Conecta a função principal ao evento de submissão
        const form = document.getElementById('formulario-cadastro');
        if (form) {
            form.addEventListener('submit', validarEEnviar);
        }
        
        // Pré-preenche o Formulário (Permite a Edição)
        const dadosSalvos = sessionStorage.getItem('dadosFormulario');
        if (dadosSalvos) {
            const dados = JSON.parse(dadosSalvos);
            
            document.getElementById('nome').value = dados.nome || '';
            document.getElementById('sobrenome').value = dados.sobrenome || '';
            document.getElementById('email').value = dados.email || '';
            document.getElementById('idade').value = dados.idade || '';
        }
    } 
    
    // --- Lógica para confirmation.html (Download ao Finalizar e EXIBIÇÃO DE DADOS) ---
    if (window.location.pathname.endsWith('confirmation.html')) {
        const dadosSalvos = sessionStorage.getItem('dadosFormulario');
        const containerDados = document.getElementById('dados-confirmacao');
        const botaoFinalizar = document.getElementById('botao-finalizar');

        if (dadosSalvos) {
            const dados = JSON.parse(dadosSalvos);

            // 🌟 A CORREÇÃO PRINCIPAL: Exibir os dados no HTML 
            containerDados.innerHTML = `
                <p><strong>Nome:</strong> ${dados.nome}</p>
                <p><strong>Sobrenome:</strong> ${dados.sobrenome}</p>
                <p><strong>E-mail:</strong> ${dados.email}</p>
                <p><strong>Idade:</strong> ${dados.idade} anos</p>
            `;

            // Adiciona o listener do botão Finalizar (Download + Redirecionamento)
            if (botaoFinalizar) {
                botaoFinalizar.addEventListener('click', () => {
                    baixarJSON(dados, 'data.json');
                    
                    // Pequeno atraso para evitar bloqueio do download
                    setTimeout(() => {
                        window.location.href = 'index.html'; 
                    }, 500); 
                });
            }

        } else {
            // Se não houver dados salvos, exibe mensagem de erro e esconde o botão
            containerDados.innerHTML = '<p>Nenhum dado encontrado. Por favor, <a href="form.html">preencha o formulário</a>.</p>';
            if (botaoFinalizar) {
                 botaoFinalizar.style.display = 'none';
            }
        }
    }
});